/*
        NSMovieView.h
        Copyright (c) 1998-2019, Apple Inc. All rights reserved.
*/

#warning NSMovieView is deprecated, and does not exist on 64-bit architectures. This header will be removed from the framework in a future release.

/*
	File:           AVAudioFormat.h
	Framework:      AVFoundation
	
	Copyright 2016 Apple Inc. All rights reserved.
*/

#import <AVFAudio/AVAudioFormat.h>


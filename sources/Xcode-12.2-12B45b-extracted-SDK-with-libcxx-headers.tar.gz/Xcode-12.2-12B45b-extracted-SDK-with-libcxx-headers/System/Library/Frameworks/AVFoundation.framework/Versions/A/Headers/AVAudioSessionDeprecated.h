/*
	File:           AVAudioSessionDeprecated.h
	Framework:      AVFoundation
	
	Copyright 2020 Apple Inc. All rights reserved.
*/

#if __has_include(<AVFAudio/AVAudioSessionDeprecated.h>)
#import <AVFAudio/AVAudioSessionDeprecated.h>
#endif

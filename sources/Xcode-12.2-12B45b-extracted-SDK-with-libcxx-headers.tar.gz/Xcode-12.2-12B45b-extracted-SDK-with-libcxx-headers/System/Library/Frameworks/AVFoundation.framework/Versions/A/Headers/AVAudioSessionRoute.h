/*
	File:           AVAudioSessionRoute.h
	Framework:      AVFoundation
	
	Copyright 2020 Apple Inc. All rights reserved.
*/

#if __has_include(<AVFAudio/AVAudioSessionRoute.h>)
#import <AVFAudio/AVAudioSessionRoute.h>
#endif
